﻿using RabbitMQ.Client;

namespace Producer.RabbitMQ
{
    public interface IRabbitMqConnection
    {
        IConnection Connection { get; }
    }
}
