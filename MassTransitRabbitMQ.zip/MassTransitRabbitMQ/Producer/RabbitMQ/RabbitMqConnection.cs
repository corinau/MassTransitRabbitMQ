﻿using RabbitMQ.Client;

namespace Producer.RabbitMQ
{
    public class RabbitMqConnection : IRabbitMqConnection, IDisposable
    {
        private IConnection? _connection;
        public IConnection Connection => _connection!;

        public RabbitMqConnection()
        {
            InitializeConnection();
        }

        private void InitializeConnection()
        {
            var factory = new ConnectionFactory 
            { 
                HostName = "localhost",
                UserName= "guest",
                Password = "guest"
            };

            factory.CreateConnection();
        }

        public void Dispose()
        {
            _connection?.Dispose();
        }
    }
}
