﻿using Microsoft.AspNetCore.Mvc;
using Producer.Dtos;
using Producer.Service;

namespace Producer.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost]
        public IActionResult SaveOrder(OrderDto order)
        {
            _orderService.SaveOrder(order);

            return Ok();
        }
    }
}
