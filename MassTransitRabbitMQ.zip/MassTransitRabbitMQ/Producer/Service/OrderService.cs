﻿using MassTransit;
using Producer.Data;
using Producer.Dtos;
using SharedModels;

namespace Producer.Service
{
    public class OrderService : IOrderService
    {
        //private readonly OrderDbContext _context;
        private readonly IPublishEndpoint _publishEndpoint;
        public OrderService(IPublishEndpoint publishEndpoint)
        {
            _publishEndpoint = publishEndpoint;
        }

        public async Task SaveOrder(OrderDto orderDto)
        {
            var order = await Save(orderDto);

            if (order != null)
            {
                await _publishEndpoint.Publish<OrderCreated>(new { 
                    orderDto.Id,
                    orderDto.Name,
                    orderDto.Price
                });
            }
        }

        private async Task<Order> Save(OrderDto orderDto)
        {
            return new Order
            {
                Id = orderDto.Id,
                Name = orderDto.Name,
                Price = orderDto.Price
            };
        }
    }
}
