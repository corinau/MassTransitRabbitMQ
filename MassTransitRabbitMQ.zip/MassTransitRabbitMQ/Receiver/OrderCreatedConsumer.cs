﻿using MassTransit;
using SharedModels;
using System.Text.Json;

namespace Receiver
{
    public class OrderCreatedConsumer : IConsumer<OrderCreated>
    {
        public async Task Consume(ConsumeContext<OrderCreated> context)
        {
            var jsonMessage = JsonSerializer.Serialize(context.Message);

            Console.Write($"Received message: {jsonMessage}");

            await Task.CompletedTask;
        }
    }
}
